"use client"

import { createContext, useState, useContext, useEffect } from "react"

const LanguageContext = createContext()

const translations = {
  es: {
    "search-placeholder": "Buscar en WikiConflicts...",
    "back-button": "← Volver",
    "no-content": "No hay contenido disponible para esta sección.",
    loading: "Cargando contenido...",
    terminology: "Terminología",
    characters: "Personajes",
    organizations: "Organizaciones",
    concepts: "Conceptos",
    "conflict-description": "Descripción del conflicto",
    photos: "Fotos",
    videos: "Vídeos",
    "select-section": "Seleccione una sección",
    home: "Inicio",
    footer: "Todos los derechos reservados",
    "loading-country": "Cargando país",
  },
  en: {
    "search-placeholder": "Search WikiConflicts...",
    "back-button": "← Back",
    "no-content": "No content available for this section.",
    loading: "Loading content...",
    terminology: "Terminology",
    characters: "Characters",
    organizations: "Organizations",
    concepts: "Concepts",
    "conflict-description": "Conflict Description",
    photos: "Photos",
    videos: "Videos",
    "select-section": "Select a section",
    home: "Home",
    footer: "All rights reserved",
    "loading-country": "Loading country",
  },
  ar: {
    "search-placeholder": "ابحث في ويكي كونفليكتس...",
    "back-button": "← العودة",
    "no-content": "لا توجد محتويات متاحة لهذا القسم.",
    loading: "جاري التحميل...",
    terminology: "المصطلحات",
    characters: "الشخصيات",
    organizations: "المنظمات",
    concepts: "المفاهيم",
    "conflict-description": "وصف النزاع",
    photos: "الصور",
    videos: "مقاطع فيديو",
    "select-section": "حدد قسماً",
    home: "الصفحة الرئيسية",
    footer: "جميع الحقوق محفوظة",
    "loading-country": "جاري تحميل البلد",
  },
  fr: {
    "search-placeholder": "Rechercher dans WikiConflicts...",
    "back-button": "← Retour",
    "no-content": "Aucun contenu disponible pour cette section.",
    loading: "Chargement du contenu...",
    terminology: "Terminologie",
    characters: "Personnages",
    organizations: "Organisations",
    concepts: "Concepts",
    "conflict-description": "Description du conflit",
    photos: "Photos",
    videos: "Vidéos",
    "select-section": "Sélectionnez une section",
    home: "Accueil",
    footer: "Tous droits réservés",
    "loading-country": "Chargement du pays",
  },
}

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState(() => {
    return localStorage.getItem("wikilang") || "es"
  })

  useEffect(() => {
    localStorage.setItem("wikilang", lang)
    document.documentElement.lang = lang
  }, [lang])

  const t = (key) => {
    return translations[lang]?.[key] || translations.es[key] || key
  }

  return <LanguageContext.Provider value={{ lang, setLang, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  return useContext(LanguageContext)
}
