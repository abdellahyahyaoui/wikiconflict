"use client"

import { useState } from "react"
import { useLanguage } from "../context/LanguageContext"
import "./country-header.css"

const LANGS = [
  { code: "es", label: "🇪🇸", alt: "Español" },
  { code: "en", label: "🇬🇧", alt: "English" },
  { code: "ar", label: "🇸🇦", alt: "العربية" },
  { code: "fr", label: "🇫🇷", alt: "Français" },
]

export default function CountryHeader({ onHomeClick = () => {}, onSearch = () => {} }) {
  const [open, setOpen] = useState(false)
  const { lang, setLang, t } = useLanguage()
  const [searchTerm, setSearchTerm] = useState("")

  function toggleMenu() {
    setOpen((v) => !v)
  }

  function changeLang(code) {
    setLang(code)
    setOpen(false)
    // Only reload if data files need to be fetched from new language folder
    setTimeout(() => window.location.reload(), 100)
  }

  function handleLogoClick(e) {
    if (e.type === "click" || (e.type === "keydown" && (e.key === "Enter" || e.key === " "))) {
      e.preventDefault()
      onHomeClick()
    }
  }

  function handleSearchChange(e) {
    const value = e.target.value
    setSearchTerm(value)
    onSearch(value)
  }

  return (
    <header className="country-header">
      <div
        className="header-left"
        onClick={handleLogoClick}
        onKeyDown={handleLogoClick}
        role="button"
        tabIndex={0}
        style={{ cursor: "pointer" }}
      >
        <div className="header-logo">
          <span className="logo-wiki">Wiki</span>
          <span className="logo-conflicts">conflicts</span>
        </div>
        <div className="header-quote">La historia contada desde su presente</div>
      </div>

      <div className="header-center">
        <div className="search-wrapper">
          <input
            className="header-search"
            type="search"
            placeholder={t("search-placeholder")}
            aria-label={t("search-placeholder")}
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </div>
      </div>

      <div className="header-right">
        <button
          className="lang-toggle"
          onClick={toggleMenu}
          aria-expanded={open}
          aria-haspopup="true"
          aria-label="Seleccionar idioma"
          title="Change language"
        >
          🌐
        </button>

        <div className={`lang-menu ${open ? "open" : ""}`} role="menu">
          {LANGS.map((l) => (
            <button
              key={l.code}
              className={`lang-option ${lang === l.code ? "active" : ""}`}
              onClick={() => changeLang(l.code)}
              role="menuitem"
              aria-label={l.alt}
              title={l.alt}
            >
              <span className="flag-emoji" aria-hidden>
                {l.label}
              </span>
              <span className="lang-label">{l.alt}</span>
            </button>
          ))}
        </div>
      </div>
    </header>
  )
}
