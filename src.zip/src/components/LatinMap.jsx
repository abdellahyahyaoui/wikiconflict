"use client"

import WorldMap from "./WorldMap"

export default function LatinMap() {
  return <WorldMap region="latin" />
}
