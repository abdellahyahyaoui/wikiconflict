"use client"

import { useState, useEffect } from "react"
import WorldMap from "./WorldMap"
import LatinMap from "./LatinMap"

export default function WorldMapScroller() {
  const [showArrow, setShowArrow] = useState(true)

  useEffect(() => {
    const onScroll = () => {
      if (window.scrollY > 20) setShowArrow(false)
      else setShowArrow(true)
    }

    window.addEventListener("scroll", onScroll)
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  const goToLatinAmerica = () => {
    window.scrollTo({
      top: window.innerHeight,
      behavior: "smooth",
    })
  }

  return (
    <div
      style={{
        height: "200vh",
        overflowY: "scroll",
        scrollSnapType: "y mandatory",
      }}
    >
      {/* PANEL 1 — Mundo árabe */}
      <section
        style={{
          height: "100vh",
          scrollSnapAlign: "start",
          position: "relative",
          background: "black",
        }}
      >
        <WorldMap region="arab" />

        {showArrow && (
          <div
            onClick={goToLatinAmerica}
            style={{
              position: "absolute",
              bottom: "40px",
              left: "50%",
              transform: "translateX(-50%)",
              fontSize: "60px",
              color: "white",
              opacity: 0.9,
              cursor: "pointer",
              animation: "bounce 1.5s infinite",
              zIndex: 9999,
            }}
          >
            ↓
          </div>
        )}
      </section>

      {/* PANEL 2 — Latinoamérica */}
      <section
        style={{
          height: "100vh",
          scrollSnapAlign: "start",
          position: "relative",
          background: "#111",
        }}
      >
        <LatinMap />
      </section>

      <style jsx>{`
        @keyframes bounce {
          0% {
            transform: translate(-50%, 0);
          }
          50% {
            transform: translate(-50%, 12px);
          }
          100% {
            transform: translate(-50%, 0);
          }
        }
      `}</style>
    </div>
  )
}
