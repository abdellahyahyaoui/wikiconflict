"use client"
import "./mobile-navigation.css"

export default function MobileNavigation() {
  return null
}
