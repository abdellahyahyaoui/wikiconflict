"use client"

import "./Home.css"
import { useState, useEffect } from "react"
import WorldMap from "../components/WorldMap"
import FloatingCountries from "../components/FloatingCountries"

function Home() {
  const [isMobile, setIsMobile] = useState(false)
  const [isAnimated, setIsAnimated] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 860)
    checkMobile()
    window.addEventListener("resize", checkMobile)

    const timer = setTimeout(() => setIsAnimated(true), 1500)

    return () => {
      window.removeEventListener("resize", checkMobile)
      clearTimeout(timer)
    }
  }, [])

  if (isMobile) {
    return (
      <div className={`mobile-home ${isAnimated ? "animated" : ""}`}>
        <div className="mobile-home-search">
          <input
            type="search"
            className="mobile-search-input"
            placeholder="Buscar en WikiConflicts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            aria-label="Buscar contenido"
          />
        </div>

        <div className="mobile-brand-center">
          <h1 className="title-main">
            <span className="title-wiki">Wiki</span>
            <span className="title-conflicts">Conflicts</span>
          </h1>
          <p className="mobile-quote">
            "Y mientras el verdugo insista en escribir la historia, mi deber será arrancarle la pluma."
          </p>
        </div>

        <div className={`mobile-country-selector ${isAnimated ? "visible" : ""}`}>
          <FloatingCountries isDropdown={true} />
        </div>
      </div>
    )
  }

  return (
    <div className="home-container">
      <div className="title-block">
        <h1 className="title-main">
          <span className="title-wiki">Wiki</span>
          <span className="title-conflicts">Conflicts</span>
        </h1>
        <h2 className="title-sub">Archivo Documental del Mundo Árabe</h2>

        {/* <p className="quote">
          "Y mientras el verdugo insista en escribir la historia, mi deber será arrancarle la pluma."
        </p> */}
      </div>

      <WorldMap />
    </div>
  )
}

export default Home
