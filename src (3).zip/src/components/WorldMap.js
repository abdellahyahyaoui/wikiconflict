"use client"

import { useState } from "react"
import { ComposableMap, Geographies, Geography, Marker } from "react-simple-maps"
import "./WorldMap.css"

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json"

// ---------------------------
// LISTA DE PAISES ÁRABES + Turquía e Irán
// ---------------------------
const arabCountries = [
  "Algeria", "Bahrain", "Comoros", "Egypt", "Iraq", "Israel", "Jordan",
  "Kuwait", "Lebanon", "Libya", "Mauritania", "Morocco", "Oman", "Qatar",
  "Saudi Arabia", "Sudan", "South Sudan", "Syria", "Tunisia",
  "United Arab Emirates", "Yemen", "Western Sahara",
  "Palestinian Territory, Occupied",
]

const extraArab = ["Turkey", "Iran"]

const regionFilters = arabCountries.concat(extraArab)

// ---------------------------
// DATOS DE PAISES
// ---------------------------
const countryData = {
  morocco: { name: "Marruecos", coordinates: [-6.8498, 34.0209], image: "/morocco-atlas-mountains-medina.jpg", description: "Reino antiguo que conecta África y Europa", hasConflict: false },
  palestine: { name: "Palestina", coordinates: [35.2, 31.9], image: "/israel-palestine-landscape.jpg", description: "Territorio en conflicto con historia milenaria", hasConflict: true },
  lebanon: { name: "Líbano", coordinates: [35.5018, 33.8886], image: "/morocco-atlas-mountains-medina.jpg", description: "País mediterráneo con rica diversidad cultural", hasConflict: true },
  yemen: { name: "Yemen", coordinates: [44.2075, 15.3694], image: "/algeria-flag-desert-landscape.jpg", description: "Antigua Arabia Felix, ahora en crisis humanitaria", hasConflict: true },
  turkey: { name: "Turquía", coordinates: [32.8597, 39.9334], image: "/turkey-istanbul-landscape.jpg", description: "Puente entre Europa y Asia", hasConflict: false },
  iran: { name: "Irán", coordinates: [51.3890, 35.6892], image: "/iran-tehran-landscape.jpg", description: "Antigua civilización persa", hasConflict: false },
  algeria: { name: "Argelia", coordinates: [3.0588, 36.7538], image: "/algeria-flag-desert-landscape.jpg", description: "El país más grande de África con herencia bereber y árabe", hasConflict: false },
  egypt: { name: "Egipto", coordinates: [31.2357, 30.0444], image: "/egypt-pyramids-nile.jpg", description: "Cuna de la civilización antigua", hasConflict: false },
  sudan: { name: "Sudán", coordinates: [32.5599, 15.5007], image: "/egypt-pyramids-nile.jpg", description: "País africano con historia nubia y árabe", hasConflict: false },
  saudi: { name: "Arabia Saudita", coordinates: [46.6753, 24.7136], image: "/algeria-flag-desert-landscape.jpg", description: "Guardián de los lugares sagrados del Islam", hasConflict: false },
  uae: { name: "Emiratos Árabes Unidos", coordinates: [54.3705, 24.4539], image: "/libya-sahara-desert.jpg", description: "Federación moderna de siete emiratos", hasConflict: false },
  qatar: { name: "Catar", coordinates: [51.531, 25.2854], image: "/morocco-atlas-mountains-medina.jpg", description: "Pequeño pero próspero estado del Golfo", hasConflict: false },
  bahrain: { name: "Baréin", coordinates: [50.5577, 26.0667], image: "/algeria-flag-desert-landscape.jpg", description: "Nación insular del Golfo Pérsico", hasConflict: false },
  jordan: { name: "Jordania", coordinates: [35.9456, 31.9454], image: "/algeria-flag-desert-landscape.jpg", description: "Reino hachemita con rica herencia histórica", hasConflict: false },
  iraq: { name: "Irak", coordinates: [44.3661, 33.3152], image: "/libya-sahara-desert.jpg", description: "Tierra de Mesopotamia, cuna de la civilización", hasConflict: false },
  kuwait: { name: "Kuwait", coordinates: [47.9774, 29.3759], image: "/morocco-atlas-mountains-medina.jpg", description: "Estado del Golfo rico en petróleo", hasConflict: false },
  libya: { name: "Libia", coordinates: [13.1913, 32.8872], image: "/libya-sahara-desert.jpg", description: "Nación sahariana con costa mediterránea", hasConflict: false },
  tunisia: { name: "Túnez", coordinates: [10.1815, 36.8065], image: "/morocco-atlas-mountains-medina.jpg", description: "País mediterráneo con rica historia cartaginesa", hasConflict: false },
  oman: { name: "Omán", coordinates: [58.4059, 23.588], image: "/egypt-pyramids-nile.jpg", description: "Sultanato en la costa sur de la Península Arábiga", hasConflict: false },
  mauritania: { name: "Mauritania", coordinates: [-15.9785, 18.0735], image: "/libya-sahara-desert.jpg", description: "Puente entre el Magreb y África Subsahariana", hasConflict: false },
  comoros: { name: "Comoras", coordinates: [43.2418, -11.7172], image: "/morocco-atlas-mountains-medina.jpg", description: "Nación insular en el Océano Índico", hasConflict: false },
}

// ---------------------------
// COMPONENTE
// ---------------------------
export default function WorldMap() {
  const [hoveredCountry, setHoveredCountry] = useState(null)

  const getCountryId = (geo) => {
    const name = geo.properties.name.toLowerCase()
    if (geo.id === "732" || name === "morocco" || name === "western sahara") return "morocco"
    const israelIds = ["376", "275"]
    const israelNames = ["israel", "palestine", "west bank", "gaza"]
    if (israelIds.includes(geo.id) || israelNames.includes(name)) return "palestine"
    if (name === "saudi arabia") return "saudi"
    if (name === "united arab emirates") return "uae"
    return name.replace(/\s+/g, "-")
  }

  const handleCountryClick = (countryId) => {
    const routeId = countryId === "israel" ? "palestine" : countryId
    window.location.href = `/country/${routeId}`
  }

  return (
    <div className="map-wrapper" style={{ position: "relative" }}>
      <ComposableMap
        projection="geoMercator"
        projectionConfig={{ scale: 700, center: [25, 28] }}
        style={{ width: "100%", height: "105%" }}
      >
        <Geographies geography={geoUrl}>
          {({ geographies }) =>
            geographies
              .filter((geo) => regionFilters.includes(geo.properties.name) || geo.id === "732" || geo.id === "275")
              .map((geo) => {
                const countryId = getCountryId(geo)
                const isHovered = hoveredCountry === countryId
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    onClick={() => handleCountryClick(countryId)}
                    onMouseEnter={() => setHoveredCountry(countryId)}
                    onMouseLeave={() => setHoveredCountry(null)}
                      fill={isHovered ? "#184a5fff" : "#07202b"}
                    stroke="#ffffffff"
                    strokeWidth={0.5}
                    style={{
                      default: { outline: "none", cursor: "pointer" },
                       hover: { outline: "none", fill: "#184a5f" },
                      pressed: { outline: "none" },
                    }}
                  />
                )
              })
          }
        </Geographies>

        {/* SOLO MARCADORES EN CONFLICTO */}
        {Object.entries(countryData).map(([id, data]) => {
          if (!data.hasConflict) return null
          return (
            <Marker key={id} coordinates={data.coordinates}>
              <g onMouseEnter={() => setHoveredCountry(id)} onMouseLeave={() => setHoveredCountry(null)} style={{ cursor: "pointer" }}>
                <circle r="20" className="conflict-marker-pulse" />
                <circle r="20" className="conflict-marker-pulse" style={{ animationDelay: "0.5s" }} />
                <circle r="20" className="conflict-marker-pulse" style={{ animationDelay: "1s" }} />
                <circle r="20" className="conflict-marker-pulse" style={{ animationDelay: "1.5s" }} />
                <circle r="6" fill="#ef4444" stroke="white" strokeWidth="1" />
              </g>
            </Marker>
          )
        })}
      </ComposableMap>

      {/* POPUP CIRCULAR FIJO ARRIBA-IZQUIERDA */}
      {hoveredCountry && countryData[hoveredCountry] && (
        <div
          className="country-popup-circle"
          style={{
            position: "absolute",
            top: "-90px",
            left: "320px",
            width: 200,
            height: 200,
            borderRadius: "50%",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "#ffffffee",
            boxShadow: "0 0 15px rgba(0,0,0,0.3)",
            padding: "10px",
            textAlign: "center",
          }}
        >
          <img
            src={countryData[hoveredCountry].image}
            alt={countryData[hoveredCountry].name}
            style={{ width: "80px", height: "80px", borderRadius: "50%", marginBottom: "10px", objectFit: "cover" }}
          />
          <h3 style={{ fontSize: "16px", margin: 0 }}>{countryData[hoveredCountry].name}</h3>
          <p style={{ fontSize: "12px", margin: 0 }}>{countryData[hoveredCountry].description}</p>
        </div>
      )}
    </div>
  )
}
